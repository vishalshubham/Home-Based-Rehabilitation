<?php
  session_start(); 
  $_SESSION['myvar'] = 'helli';
?>

<a href="second.php">hell</a>